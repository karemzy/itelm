<?php
session_start();
include('../server/dbconfig.php');
if (!isset($_SESSION['adminid'])) {
  header('Location:login');
  exit();
} else {
  $adminid = $_SESSION['adminid'];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Dashboard</title>
  <link rel="shortcut icon" href="../img/favicon.ico" />
  <link rel="icon" href="../img/favicon.ico" type="image/x-icon">
  <!-- Google Font: Source Sans Pro -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="plugins/fontawesome-free/css/all.min.css">
  <!-- Select2 -->
  <link rel="stylesheet" href="plugins/select2/css/select2.min.css">
  <link rel="stylesheet" href="plugins/select2-bootstrap4-theme/select2-bootstrap4.min.css">
  <!-- DataTables -->
  <link rel="stylesheet" href="plugins/datatables-bs4/css/dataTables.bootstrap4.min.css">
  <link rel="stylesheet" href="plugins/datatables-responsive/css/responsive.bootstrap4.min.css">
  <link rel="stylesheet" href="plugins/datatables-buttons/css/buttons.bootstrap4.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/adminlte.min.css">
  <style>
    div.dataTables_wrapper div.dataTables_filter input[type="search"] {    
      width: 130px;
    }
  </style>
</head>
<body class="hold-transition sidebar-mini">

  <!-- Modal -->
  <div class="modal fade" id="readRequestModal" data-backdrop="static" data-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-scrollable modal-dialog-centered">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="staticBackdropLabel">Read Request</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close" id="closeModal">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
          <div id="readRequest" class="card border-0 rounded-0 shadow-none">
            
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        </div>
      </div>
    </div>
  </div>

  <!-- Modal -->
  <div class="modal fade" id="replyRequestModal" data-backdrop="static" data-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-scrollable modal-dialog-centered">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="staticBackdropLabel">Read Request</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close" id="closeModal">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
          <div id="replyRequest" class="card border-0 rounded-0 shadow-none">
            
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        </div>
      </div>
    </div>
  </div>

  <!-- Modal -->
  <div class="modal fade" id="newsletterModal" data-backdrop="static" data-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-scrollable modal-dialog-centered">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="staticBackdropLabel">Send Newsletter</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close" id="closeModal">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
          <div id="newsletter" class="card border-0 rounded-0 shadow-none">
            <div class="card-body">
              <form id="newsletterForm">
                <input type="hidden" name="newsletter">
                <div class="form-group">
                  <textarea name="message" id="" cols="30" rows="10" class="form-control"></textarea>
                </div>
                <div class="form-group">
                  <button type="submit" id="nBtn" class="btn btn-primary">Send</button>
                </div>
                <p id="nMsg" class="text-muted"></p>
              </form>
                
            </div>
            <div id="loader3" class="overlay" style="display: none;"><i class="fas fa-2x fa-sync-alt fa-spin"></i></div>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        </div>
      </div>
    </div>
  </div>

  <div class="wrapper">
    <!-- Preloader -->
    <div class="preloader flex-column justify-content-center align-items-center">
      <div class="spinner-grow text-info" role="status"></div>
    </div>

    <!-- Navbar -->
    <nav class="main-header navbar navbar-expand navbar-white navbar-light">
      <!-- Left navbar links -->
      <ul class="navbar-nav">
        <li class="nav-item">
          <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
        </li>
      </ul>

      <ul class="navbar-nav">
        <li class="nav-item">
          <!-- Button trigger modal -->
          <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#newsletterModal">
            Send Newsletter
          </button>
        </li>
        
      </ul>

      <!-- Right navbar links -->
      <ul class="navbar-nav ml-auto">

      </ul>

    </nav>
    <!-- /.navbar -->

    <!-- Main Sidebar Container -->
    <aside class="main-sidebar sidebar-dark-primary elevation-4">
      
      <!-- Sidebar -->
      <div class="sidebar">
       

        <!-- Sidebar Menu -->
        <nav class="mt-2">
          <ul class="nav nav-pills nav-sidebar flex-column pt-5" data-widget="treeview" role="menu" data-accordion="false">
            
          </ul>
        </nav>
        <!-- /.sidebar-menu -->
      </div>
      <!-- /.sidebar -->
    </aside>
    
    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">

      <!-- Main content -->
      <section class="content">
        <div class="container-fluid">
          <!-- Main row -->
          <div class="row pt-4">
            <div class="col-12">
              <div class="card rounded-0">
                <div class="card-body table-responsive">
                  <?php  
                  $mysqli = $db_conn->query("SELECT * FROM requests ORDER BY id DESC");
                  if($mysqli->num_rows > 0) 
                  {
                    echo '
                    <table id="example2" class="update1 table table-sm table-hover" style="font-size: 14px;">
                      <thead>
                        <tr>
                          <th>#</th>
                          <th>Name</th>
                          <th>Email</th>
                          <th>Phone</th>
                          <th>Subject</th>
                          <th>Date</th>
                          <th>Read</th>
                          <th>Reply</th>
                          <th>Action</th>
                        </tr>
                      </thead>
                      <tbody>
                    ';
                    while($row = $mysqli->fetch_assoc()) 
                    {
                      echo '<tr>';
                      echo '<td>'.$row['id'].'</td>';
                      echo '<td>'.$row['fname'].'</td>';
                      echo '<td>'.$row['email'].'</td>';
                      echo '<td>'.$row['phoneno'].'</td>';
                      echo '<td>'.$row['subject'].'</td>';
                      echo '<td>'.$row['msg_time'].'</td>';
                      echo '<td><a data-id="'.$row['id'].'" data-type="open" class="read_request btn btn-sm btn-primary text-capitalize">Read</a></td>';
                      echo '<td><a data-id="'.$row['id'].'" data-type="open" class="reply_request btn btn-sm btn-warning text-capitalize">Reply</a></td>';
                      echo '<td><a data-id="'.$row['id'].'" data-type="delete"class="delete_request btn btn-sm btn-danger text-capitalize">Delete</a></td>';
                      echo '</tr>';
                    }
                    echo '
                      </tbody>
                    </table>
                    ';
                  }
                  else
                  {
                    echo '
                    <table id="example2" class="table table-sm table-hover" style="font-size: 14px;">
                      <thead>
                        <tr>
                          <th>#</th>
                          <th>Name</th>
                          <th>Email</th>
                          <th>Phone</th>
                          <th>Message</th>
                          <th>Date</th>
                          <th></th>
                          <th></th>
                          <th></th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <td>#</td>
                          <td>Name</td>
                          <td>Email</td>
                          <td>Phone</td>
                          <td>Message</td>
                          <td>Date</td>
                          <td></td>
                          <td></td>
                          <td></td>
                        </tr>
                      </body>
                    ';
                  }
                  ?>  
                    
                </div>
                <div id="loader" class="overlay" style="display: none;"><i class="fas fa-2x fa-sync-alt fa-spin"></i></div>
              </div>
            </div>
            
            <div class="col-12">
              <div class="card rounded-0">
                <div class="card-body table-responsive">
                  <?php  
                  $mysqli = $db_conn->query("SELECT * FROM subscribers ORDER BY id DESC");
                  if($mysqli->num_rows > 0) 
                  {
                    echo '
                    <table id="example1" class="update2 table table-sm table-hover" style="font-size: 14px;">
                      <thead>
                        <tr>
                          <th>#</th>
                          <th>Email</th>
                          <th>Action</th>
                        </tr>
                      </thead>
                      <tbody>
                    ';
                    while($row = $mysqli->fetch_assoc()) 
                    {
                      echo '<tr>';
                      echo '<td>'.$row['id'].'</td>';
                      echo '<td>'.$row['email'].'</td>';
                      echo '<td><a data-id="'.$row['id'].'" data-type="delete"class="delete_subscriber btn btn-sm btn-danger text-capitalize">Delete</a></td>';
                      echo '</tr>';
                    }
                    echo '
                      </tbody>
                    </table>
                    ';
                  }
                  else
                  {
                    echo '
                    <table id="example2" class="table table-sm table-hover" style="font-size: 14px;">
                      <thead>
                        <tr>
                          <th>#</th>
                          <th>Email</th>
                          <th>Action</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <td>#</td>
                          <td>Email</td>
                          <td></td>
                        </tr>
                      </body>
                    ';
                  }
                  ?>  
                    
                </div>
                <div id="loader" class="overlay" style="display: none;"><i class="fas fa-2x fa-sync-alt fa-spin"></i></div>
              </div>
            </div>
          </div>
          <!-- /.row (main row) -->
        </div>
        <!-- /.container-fluid -->
      </section>
      <!-- /.content -->

      
    </div>
    <!-- /.content-wrapper -->
    <footer class="text-center main-footer">
      <span>Copyright &copy; 2021 <a href="home">Access Payday Loan</a>.</span>
    </footer>

    <!-- Control Sidebar -->
    <aside class="control-sidebar control-sidebar-dark">
      <!-- Control sidebar content goes here -->
    </aside>
    <!-- /.control-sidebar -->
  </div>
  <!-- ./wrapper -->

<!-- jQuery -->
<script src="plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- Select2 -->
<script src="plugins/select2/js/select2.full.min.js"></script>

<!-- DataTables  & Plugins -->
<script src="plugins/datatables/jquery.dataTables.min.js"></script>
<script src="plugins/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
<script src="plugins/datatables-responsive/js/dataTables.responsive.min.js"></script>
<script src="plugins/datatables-responsive/js/responsive.bootstrap4.min.js"></script>
<script src="plugins/datatables-buttons/js/dataTables.buttons.min.js"></script>
<script src="plugins/datatables-buttons/js/buttons.bootstrap4.min.js"></script>
<script src="plugins/datatables-buttons/js/buttons.html5.min.js"></script>
<script src="plugins/datatables-buttons/js/buttons.print.min.js"></script>
<script src="plugins/datatables-buttons/js/buttons.colVis.min.js"></script>

<!-- AdminLTE App -->
<script src="dist/js/adminlte.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="dist/js/demo.js"></script>
<!-- Page specific script -->
<script>
  $(document).on('click', '.read_request', function() {
    var id = $(this).attr('data-id');
    var read_request = $(this).attr('data-type');
    $.ajax({
      url: 'handler.php',
      type: 'POST',
      dataType: 'json',
      data: {id:id, read_request:read_request},
      beforeSend: function() {
        $('#loader').show();
      },
      success: function (response) {
        if (response.status == '1') {
          setTimeout(function() {
            $('#loader').hide();
          }, 2000);
          $('#readRequestModal').modal('show');
          $('#readRequest').html(response.message);
        }
      }
    });
    
  });

  $(document).on('click', '.reply_request', function() {
    var id = $(this).attr('data-id');
    var reply_request = $(this).attr('data-type');
    $.ajax({
      url: 'handler.php',
      type: 'POST',
      dataType: 'json',
      data: {id:id, reply_request:reply_request},
      beforeSend: function() {
        $('#loader').show();
      },
      success: function (response) {
        if (response.status == '1') {
          setTimeout(function() {
            $('#loader').hide();
          }, 2000);
          $('#replyRequestModal').modal('show');
          $('#replyRequest').html(response.message);
        }
      }
    });
    
  });

  $(document).on('submit', '#replyRequestForm', function(event) {
    event.preventDefault();
    $.ajax({
      url: 'handler.php',
      type: 'POST',
      dataType: 'json',
      data: $(this).serialize(),
      beforeSend: function() {
        $('#replyBtn').html('<i class="fa fa-spinner fa-spin"></i> Reply');
        $('#loader2').show();
      },
      success: function (response) {
        if (response.status == '1') {
          setTimeout(function() {
            $('#loader2').hide();
          }, 2000);
          $('#replyBtn').html('<i class="fa fa-check"></i> Message sent');
          $('#rMsg').html('<i class="fa fa-check"></i> Your mail has been sent.');
        }
      }
    });
    
  });

  $(document).on('click', '.delete_request', function() {
    var id = $(this).attr('data-id');
    var delete_request = $(this).attr('data-type');
    $.ajax({
      url: 'handler.php',
      type: 'POST',
      dataType: 'json',
      data: {id:id, delete_request:delete_request},
      beforeSend: function() {
        $('#loader').show();
      },
      success: function (response) {
        if (response.status == '1') {
          $('.update1').load(location.href + " .update1");
          $('#loader').hide();
        }
      }
    });
    
  });

  $(document).on('click', '.delete_subscriber', function() {
    var id = $(this).attr('data-id');
    var delete_subscriber = $(this).attr('data-type');
    $.ajax({
      url: 'handler.php',
      type: 'POST',
      dataType: 'json',
      data: {id:id, delete_subscriber:delete_subscriber},
      beforeSend: function() {
        $('#loader').show();
      },
      success: function (response) {
        if (response.status == '1') {
          $('.update2').load(location.href + " .update2");
          $('#loader').hide();
        }
      }
    });
    
  });

  $(document).on('submit', '#newsletterForm', function(event) {
    event.preventDefault();
    $.ajax({
      url: 'handler.php',
      type: 'POST',
      dataType: 'json',
      data: $(this).serialize(),
      beforeSend: function() {
        $('#nBtn').html('<i class="fa fa-spinner fa-spin"></i> Send');
        $('#loader3').show();
      },
      success: function (response) {
        if (response.status == '1') {
          setTimeout(function() {
            $('#loader3').hide();
          }, 2000);
          $('#nBtn').html('<i class="fa fa-check"></i> Message sent');
          $('#nMsg').html('<i class="fa fa-check"></i> Your newsletter has been sent.');
        }
      }
    });
    
  });

  $(function () {
    $("#example1").DataTable({
      "paging": true,
      "responsive": true, 
      "lengthChange": true, 
      "autoWidth": true, 
      "searching": true, 
      "ordering": true,
      "order": true,
      "info": true,
    }).buttons().container().appendTo('#example1_wrapper .col-md-6:eq(0)');
    $('#example2').DataTable({
      "paging": true,
      "lengthChange": true,
      "searching": true,
      "ordering": true,
      "order": true,
      "info": true,
      "autoWidth": true,
      "responsive": true,
    });
  });

  $(document).ready(function() {
    $('.buttons-pdf').removeClass('btn-secondary').addClass('btn-default btn-sm rounded text-info mr-2');
    $('.buttons-print').removeClass('btn-secondary').addClass('btn-default btn-sm rounded text-info');
    $('.buttons-pdf').html('Download <i class="fas fa-download"></i>');
    $('.buttons-print').html('Print <i class="fas fa-print"></i>');
    $('#example1_wrapper .col-md-6').removeClass('col-md-6 ').addClass('pb-2');
  })
</script>

</body>
</html>
