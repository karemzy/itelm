<?php
	$server_name = "127.0.0.1";
	$db_username = "itelojzp_anakfarms";
	$password = "_*ICJbJMc7@3";
	$db_name = "itelojzp_anakfarms";
	$db_conn = new mysqli($server_name,$db_username,$password,$db_name);
?>
