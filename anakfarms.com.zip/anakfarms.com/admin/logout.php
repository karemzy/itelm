<?php 
session_start();
include('dbconfig.php');
$adminid = $_SESSION['adminid'];

unset($_SESSION['adminid']);
session_destroy();
header('Location:login');
exit(); 

?>