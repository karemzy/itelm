<?php
session_start();
include('server/dbconfig.php');

$response = array( 
    'status' => 0, 
    'message' => 'Request failed, please try again.' 
);

if(isset($_POST['request'])) {
    $fname = $db_conn->real_escape_string($_POST['name']);
    $phoneno = $db_conn->real_escape_string($_POST['phoneno']);
    $email = $db_conn->real_escape_string($_POST['email']);
    $subject = $db_conn->real_escape_string($_POST['subject']);
    $message = $db_conn->real_escape_string($_POST['message']);

    $mysqli = $db_conn->query("INSERT INTO requests (fname,phoneno,email,subject,message,msg_time) VALUES ('$fname','$phoneno','$email','$subject','$message',NOW())");
    if($mysqli) {
        $response['status'] = 1; 
        $response['message'] = 'Message sent';
    } else {
        $response['status'] = 0; 
        $response['message'] = 'Message not sent';
    }
}

if(isset($_POST['subscriber_email'])) {
    $email = $db_conn->real_escape_string($_POST['subscriber_email']);

    $mysqli = $db_conn->query("INSERT INTO subscribers (email) VALUES ('$email')");
    if($mysqli) {
        $response['status'] = 1; 
        $response['message'] = 'Thank you for subscribing to our Newsletters.';
    } else {
        $response['status'] = 0; 
        $response['message'] = 'Failed';
    }
}

// Return response 
echo json_encode($response);
?>