<?php
session_start();
include('../server/dbconfig.php');

$response = array( 
    'status' => 0, 
    'message' => 'Request failed, please try again.' 
);

if(isset($_POST['login'])) {
    $adminid = $db_conn->real_escape_string($_POST['adminid']);
    $password = $db_conn->real_escape_string($_POST['password']);

    $mysqli = $db_conn->query("SELECT * FROM admin WHERE adminid = '$adminid' AND password = '$password'" );
    if($mysqli->num_rows > 0) {
        $_SESSION['adminid'] = $adminid;
        $response['status'] = 1; 
        $response['message'] = 'Success';
    } else {
        $response['status'] = 0; 
        $response['message'] = 'Incorrect login details!';
    }
}

if(isset($_POST['read_request'])) {
    $id = $db_conn->real_escape_string($_POST['id']);

    $mysqli = $db_conn->query("SELECT * FROM requests WHERE id = '$id'");
    if($mysqli->num_rows > 0) {
        $row = $mysqli->fetch_assoc();
        $response['status'] = 1; 
        $response['message'] = '
            <div class="card-body">
                <div class="h6 font-weight-bold">Sender</div>
                <div class="bg-light mb-4 p-2">
                  <div class="card-text text-secondary">'.$row['fname'].'</div>
                  <div class="card-text text-secondary">'.$row['email'].'</div>
                  <div class="card-text text-secondary">'.$row['phoneno'].'</div>
                </div>
                <p class="card-text float-right text-danger"><em>On '.$row['msg_time'].'</em></p>
                <div class="h6 font-weight-bold">Subject</div>
                <p class="card-text bg-secondary text-white p-2">'.$row['subject'].'</p>
                <div class="h6 font-weight-bold">Message</div>
                <p class="card-text p-2 bg-secondary text-white">'.$row['message'].'</p>
              
            </div>
        ';
    } else {
        $response['status'] = 0; 
        $response['message'] = 'Not deleted';
    }
}

if(isset($_POST['reply_request'])) {
    $id = $db_conn->real_escape_string($_POST['id']);

    $mysqli = $db_conn->query("SELECT * FROM requests WHERE id = '$id'");
    if($mysqli->num_rows > 0) {
        $row = $mysqli->fetch_assoc();
        $response['status'] = 1; 
        $response['message'] = '
            <div class="card-body">
                <div class="h6 font-weight-bold">Client Information</div>
                <div class="bg-light mb-4 p-2">
                  <div class="card-text text-secondary">'.$row['fname'].'</div>
                  <div class="card-text text-secondary">'.$row['email'].'</div>
                  <div class="card-text text-secondary">'.$row['phoneno'].'</div>
                </div>
                <div class="h6 font-weight-bold">Subject</div>
                <p class="card-text bg-light text-dark p-2">RE: '.$row['subject'].'</p>
                <div class="h6 font-weight-bold">Message</div>
                <p class="card-text p-2 bg-light text-dark">'.$row['message'].'</p>
                <form id="replyRequestForm">
                  <input type="hidden" name="reply_msg">
                  <input type="hidden" name="email" value="'.$row['email'].'">
                  <input type="hidden" name="subject" value="Re: '.$row['subject'].'">
                  <div class="form-group">
                    <textarea name="message" class="form-control" cols="30" rows="5" placeholder="Enter reply"></textarea>
                  </div>
                  <div class="form-group"><button type="submit" id="replyBtn" class="btn btn-primary">Reply</button></div>
                  <p id="rMsg" class="text-muted"></p>
                </form>
            </div>
            <div id="loader2" class="overlay" style="display: none;"><i class="fas fa-2x fa-sync-alt fa-spin"></i>
        ';
    } else {
        $response['status'] = 0; 
        $response['message'] = 'Not deleted';
    }
}

if (isset($_POST['reply_msg'])) {
    $email = $db_conn->real_escape_string($_POST['email']);
    $subject = $db_conn->real_escape_string($_POST['subject']);
    $msg = $db_conn->real_escape_string($_POST['message']);

    $message = '
    <p>'.$msg.'</p>
    <p>This is an automated message, please do not reply</p>
    ';

    $header = "MIME-Version:1.0"."\r\n";
    $header .= "Content-type:text/html;charset=UTF-8"."\r\n";

    $header .= "From: Anakfarms<no-reply@anakfarms.com>"."\r\n";
    $header .= "Bcc:<info@anakfarms.com>"."\r\n";

    if (mail($email,$subject,$message,$header)) {
        $response['status'] = 1; 
        $response['message'] = 'Success';
    }        
}

if(isset($_POST['delete_request'])) {
    $id = $db_conn->real_escape_string($_POST['id']);

    $mysqli = $db_conn->query("DELETE FROM requests WHERE id = '$id'");
    if($mysqli) {
        $response['status'] = 1; 
        $response['message'] = 'Deleted';
    } else {
        $response['status'] = 0; 
        $response['message'] = 'Not deleted';
    }
}

if(isset($_POST['delete_subscriber'])) {
    $id = $db_conn->real_escape_string($_POST['id']);

    $mysqli = $db_conn->query("DELETE FROM subscribers WHERE id = '$id'");
    if($mysqli) {
        $response['status'] = 1; 
        $response['message'] = 'Deleted';
    } else {
        $response['status'] = 0; 
        $response['message'] = 'Not deleted';
    }
}

if (isset($_POST['newsletter'])) {
    $msg = $db_conn->real_escape_string($_POST['message']);

    $mysqli = $db_conn->query("SELECT * FROM subscribers");
    $row = $mysqli->fetch_assoc();

    $email = $row['email'];

    $message = '
    <p>'.$msg.'</p>
    <p>This is an automated message, please do not reply</p>
    ';

    $header = "MIME-Version:1.0"."\r\n";
    $header .= "Content-type:text/html;charset=UTF-8"."\r\n";

    $header .= "From: Anakfarms<no-reply@anakfarms.com>"."\r\n";
    $header .= "Bcc:<info@anakfarms.com>"."\r\n";

    if (mail($email,$subject,$message,$header)) {
        $response['status'] = 1; 
        $response['message'] = 'Success';
    }
}

// Return response 
echo json_encode($response);
?>